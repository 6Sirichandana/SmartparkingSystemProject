package com.remotehiring.exceptions;

public class AdminAuthenticationException extends RuntimeException {
    public AdminAuthenticationException(String message) {
        super(message);
    }
}
